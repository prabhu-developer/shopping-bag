import { configureStore } from "@reduxjs/toolkit";
import { combineReducers } from "redux";
import { CategoryReducer } from "./slicers/CategorySlicer";

const rootReducers = combineReducers({
  category: CategoryReducer,
});

const store = configureStore({
  reducer: rootReducers,
});

export default store;
