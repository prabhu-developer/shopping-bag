import { createSlice } from "@reduxjs/toolkit";

const CategorySlicer = createSlice({
  name: "category",
  initialState: {
    value: 'jeans',
  },
  reducers: {
    setCategoryName: (state, action) => {
      state.value = action.payload;
    },
  },
});

export const { setCategoryName } = CategorySlicer.actions;
export const CategoryReducer = CategorySlicer.reducer;
