"use client";
import { Provider } from "react-redux";
import { QueryClient, QueryClientProvider } from "react-query";

import store from "./store";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      keepPreviousData: true, 
    },
  },
});

export const Providers = (props: React.PropsWithChildren) => {
  return (
    <Provider store={store}>
      <QueryClientProvider client={queryClient}>
        {props.children}
      </QueryClientProvider>
    </Provider>
  );
};
