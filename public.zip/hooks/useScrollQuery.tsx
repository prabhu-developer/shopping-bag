"use client"
import { useEffect } from "react";

function useScrollQuery(callbackFunction:Function) {
  function handleScroll() {
    const windowHeight   = window.innerHeight;
    const documentHeight = document.documentElement.scrollHeight;
    const scrollTop      = window.scrollY;
    
    if (Math.round(windowHeight + scrollTop) === documentHeight) {
      callbackFunction()
    }
  }

  useEffect(() => {
    window.addEventListener("scroll", handleScroll);
    return () => {
      window.removeEventListener("scroll", handleScroll);
    };
  }, []);

  return true;
}

export default useScrollQuery;
