"use client";

import { usePathname, useRouter, useSearchParams } from "next/navigation";
import { useCallback } from "react";

export default function useRouteQuery() {
  const router = useRouter();
  const pathname = usePathname();
  const query: any = useSearchParams();

  const createQueryString = useCallback(
    (name: string, value: string) => {
      const params = new URLSearchParams(query);
      params.set(name, value);
      return params.toString();
    },
    [query]
  );
  const setQuery = (type: string, slug: string | null) => {
    const routerString = slug ? pathname + "?" + createQueryString(type, slug) : "/";
    router.push(routerString);
  };
  return {query, setQuery};
}
