"use client";
import { FC, useRef } from "react";
import "./SearchBar.css";
import { CiSearch } from "react-icons/ci";
import { FiArrowRight } from "react-icons/fi";
import useRouteQuery from "../../../hooks/useRouteQuery";
import { BiX } from "react-icons/bi";

const SearchBar: FC = () => {
  const { query, setQuery } = useRouteQuery();
  const searchText = query.get("search");
  const inputRef: any = useRef();
  const _handleClick = (e: any) => {
    setQuery("search", inputRef.current.value);
  };
  const _handleClear = () => {
    setQuery("type", null);
    inputRef.current.value = "";
  };
  return (
    <div className="md:pt-20 pt-10 px-4 relative md:mb-10 mb-5" data-testid="SearchBar">
      <div className="bg-slate-100 absolute top-0 left-0 w-full block md:h-28 h-20 z-auto"></div>
      <div className="relative md:w-[65%] bg m-auto z-10">
        <label
          htmlFor="search-input"
          className="text-neutral-500 dark:text-neutral-300"
        >
          <span className="sr-only">Search all icons</span>
          <input
            className="block w-full outline-0 text-black border-neutral-200 focus:border-300 focus:ring focus:ring-[#ff9900] focus:ring-opacity-10 bg-white  rounded-full text-sm font-normal pl-14 py-5 pr-5 md:pl-16 shadow-lg border-0"
            id="search-input"
            ref={inputRef}
            placeholder="Type your keywords"
            type="search"
          />
          {searchText === null ? (
            <button
              className="flex items-center justify-center rounded-full !leading-none disabled:bg-opacity-70 bg-[#ff9900] hover:bg-slate-800 
          text-slate-50 absolute right-2.5 top-1/2 transform -translate-y-1/2  w-11 h-11 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-6000"
              type="button"
              onClick={_handleClick}
            >
              <FiArrowRight />
            </button>
          ) : (
            <button
              className="flex items-center justify-center rounded-full !leading-none disabled:bg-opacity-70 bg-[#ff9900] hover:bg-slate-800 
        text-slate-50 absolute right-2.5 top-1/2 transform -translate-y-1/2  w-11 h-11 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-6000"
              type="button"
              onClick={_handleClear}
            >
              <BiX />
            </button>
          )}

          <span className="absolute left-5 top-1/2 transform -translate-y-1/2 text-2xl md:left-6">
            <CiSearch className="h-5 w-5 text-[#ff9900]" />
          </span>
        </label>
      </div>
    </div>
  );
};

export default SearchBar;
