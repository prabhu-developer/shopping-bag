export default function CategoriesLoader() {
  return (
    <div className="container mx-auto">
      <ul className="flex flex-wrap sm:space-x-2">
        {[...Array(10)].map((item) => (
          <li className="relative" key={Math.random()}>
            <button key={Math.random()} className="h-6 w-[100px] bg-gray-300 badge-button animate-pulse"></button>
          </li>
        ))}
      </ul>
    </div>
  );
}