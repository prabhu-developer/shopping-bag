"use client";
import "./CategoriesMenu.css";
import { getCategories } from "../../../services/products";
import CategoryButton from "./CategoryButton";
import { useQuery } from "react-query";
import CategoriesLoader from "./CategoriesLoader";
import { FC } from "react";

const CategoriesMenu: FC = () => {
  const { data, isFetching } = useQuery({
    queryKey: ["categories"],
    queryFn: () => getCategories(),
  });

  if(isFetching) {
    return <CategoriesLoader />
  }

  return (
    <div className="container m-auto" data-testid="CategoriesMenu">
      <ul className="flex flex-wrap sm:space-x-2">
        <li className="nc-NavItem relative" data-nc-id="NavItem">
          <CategoryButton name="All items" slug={null} />
        </li>
        {data?.data?.map((item: any) => (
          <li className="relative" key={Math.random()}>
            <CategoryButton name={item.name} slug={item.slug} />
          </li>
        ))}
      </ul>
    </div>
  );
};

export default CategoriesMenu;
