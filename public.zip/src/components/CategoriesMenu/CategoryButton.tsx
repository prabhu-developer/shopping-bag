"use client";
import useRouteQuery from "../../../hooks/useRouteQuery";

export default function CategoryButton({
  slug,
  name,
}: {
  slug: string | null;
  name: string;
}) {
  const { query, setQuery } = useRouteQuery();

  const buttonClass =
    slug === query.get("type") ? "badge-button active" : "badge-button";

  const _handleClick = () => {
    setQuery("type", slug);
  };

  return (
    <button className={buttonClass} onClick={_handleClick}>
      {name}
    </button>
  );
}
