import React, { lazy, Suspense } from 'react';

const LazyCategoriesMenu = lazy(() => import('./CategoriesMenu'));

const CategoriesMenu = (props: JSX.IntrinsicAttributes & { children?: React.ReactNode; }) => (
  <Suspense fallback={null}>
    <LazyCategoriesMenu {...props} />
  </Suspense>
);

export default CategoriesMenu;
