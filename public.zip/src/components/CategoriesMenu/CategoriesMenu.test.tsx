import React from 'react';
import { render, screen } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';
import CategoriesMenu from './CategoriesMenu';

describe('<CategoriesMenu />', () => {
  test('it should mount', () => {
    render(<CategoriesMenu />);
    
    const categoriesMenu = screen.getByTestId('CategoriesMenu');

    expect(categoriesMenu).toBeInTheDocument();
  });
});