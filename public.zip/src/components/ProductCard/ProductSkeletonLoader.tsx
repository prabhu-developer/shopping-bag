const ProductSkeletonLoader = () => {
  return (
    <div className="ProductsList">
      {[...Array(4)].map((item) => (
        <div
          key={Math.random()}
          className="bg-white p-4 rounded-lg shadow block min-h-[300px] animate-pulse"
        >
          <div className="bg-gray-300 h-40 w-full rounded-lg mb-3"></div>
          <div className="h-6 w-2/3 bg-gray-300 mb-1"></div>
          <div className="h-4 w-full bg-gray-300 mb-1"></div>
          <div className="h-4 w-1/2 bg-gray-300 mb-1"></div>
          <div className="h-6 w-2/3 bg-gray-300"></div>
        </div>
      ))}
    </div>
  );
};

export default ProductSkeletonLoader;
