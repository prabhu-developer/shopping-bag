import React, { FC } from "react";
import Image from "next/image";
import Link from "next/link";

const ProductCard: FC = ({ product }: any) => (
  <Link
    href=""
    className="bg-white p-3 md:p-4 rounded-lg shadow block min-h-[280px]"
  >
    <Image
      src={product.image.thumbnail}
      alt="Product Image"
      quality={100}
      width={150}
      height={150}
      className="object-contain w-[150px] h-[150px] m-auto"
      loading="lazy"
    />
    <h2 className="sm:text-lg text-sm sm:mt-3 font-semibold text-gray-800">
      {product.name.substring(0, 25)}
    </h2>
    <p className="text-sm text-gray-600">
      {product.description.substring(0, 45)}
    </p>
    <div className="sm:mt-4 mt-2">
      <p className="text-gray-800 md:text-xl sm:text-lg font-semibold">
        ${product.max_price}
      </p>
    </div>
  </Link>
);

export default ProductCard;
