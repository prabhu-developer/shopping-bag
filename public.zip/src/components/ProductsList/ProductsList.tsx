"use client";
import { FC } from "react";
import "./ProductsList.css";
import { getProductsByCategory } from "../../../services/products";
import ProductCard from "../ProductCard/ProductCard.lazy";
import { useInfiniteQuery } from "react-query";
import useRouteQuery from "../../../hooks/useRouteQuery";
import queryString from "query-string";
import ProductSkeletonLoader from "../ProductCard/ProductSkeletonLoader";
import { BiLoaderAlt } from "react-icons/bi";

const ProductsList: FC = () => {
  const { query } = useRouteQuery();
  const category = query.get("type");
  const text = query.get("search");

  const { data, fetchNextPage, hasNextPage, isFetchingNextPage, isFetching } =
    useInfiniteQuery(
      ["products", category, text],
      ({ pageParam }) => getProductsByCategory(pageParam, category, text),
      {
        getNextPageParam: (lastPage) => {
          if (lastPage.next_page_url) {
            return queryString.parseUrl(lastPage.next_page_url).query.page;
          }
          return null;
        },
      }
    );

  return (
    <div className="container m-auto">
      {data?.pages.map((page) => {
        return (
          <div key={Math.random()} className="ProductsList ">
            {page.data.map((item: any) => (
              <ProductCard product={item} key={Math.random()} />
            ))}
          </div>
        );
      })}
      {isFetching && <ProductSkeletonLoader />}
      <center>
        <button
          className="py-2.5 px-5  my-5 mx-auto text-sm font-medium text-gray-900 bg-white rounded-lg border border-gray-200 hover:bg-gray-100 hover:text-blue-700 focus:z-10 focus:ring-4 focus:outline-none focus:ring-blue-700 focus:text-blue-700 dark:bg-gray-800 dark:text-gray-400 dark:border-gray-600 dark:hover:text-white dark:hover:bg-gray-700 inline-flex items-center"
          onClick={() => fetchNextPage()}
          disabled={!hasNextPage || isFetchingNextPage}
        >
          {isFetchingNextPage ? (
            <>
              <BiLoaderAlt className="inline w-4 h-4 mr-3 text-slate-600 animate-spin" />
              Loading...
            </>
          ) : hasNextPage ? (
            "Load More"
          ) : (
            "Nothing more to load"
          )}
        </button>
      </center>
    </div>
  );
};

export default ProductsList;
