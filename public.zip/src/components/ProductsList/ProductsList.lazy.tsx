import React, { lazy, Suspense } from 'react';

const LazyProductsList = lazy(() => import('./ProductsList'));

const ProductsList = (props: JSX.IntrinsicAttributes & { children?: React.ReactNode; }) => (
  <Suspense fallback={null}>
    <LazyProductsList {...props} />
  </Suspense>
);

export default ProductsList;
