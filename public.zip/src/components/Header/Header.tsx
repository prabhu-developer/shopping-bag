"use client";
import React, { FC, useState } from "react";
import { BiSolidShoppingBags, BiX } from "react-icons/bi";
import { FaShoppingCart } from "react-icons/fa";
import { HiOutlineBars3 } from "react-icons/hi2";

const Header: FC = () => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <nav className="bg-[#1a2744]  border-gray-200 dark:bg-gray-900">
      <div className="container flex flex-wrap items-center justify-between mx-auto p-4">
        <a
          href="#"
          className="flex text-white items-center md:text-xl font-semibold"
        >
          <BiSolidShoppingBags className="mr-3 text-[#ff9900]" size={35} />
          Shopping Bag
        </a>
        <button
          type="button"
          className="inline-flex items-center p-2 w-10 h-10 justify-center text-sm text-white rounded-lg md:hidden hover:bg-[#ff9900] focus:outline-none focus:ring-2 focus:ring-gray-200 dark:text-gray-400 dark:hover:bg-gray-700 dark:focus:ring-gray-600"
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
        >
          {mobileMenuOpen ? <BiX size={30} /> : <HiOutlineBars3 size={30} />}
        </button>

        <div className={`md:flex md:w-auto w-full ${!mobileMenuOpen ? "hidden" : ""}`}>
          <ul className="font-medium flex items-center flex-col p-4 md:p-0 mt-4 border border-gray-100 rounded-lg md:flex-row md:space-x-8 md:mt-0 md:border-0">
            <li>
              <a
                href="#"
                className="text-white text-sm hover:text-[#ff9900] leading-10"
                aria-current="page"
              >
                Home
              </a>
            </li>
            <li>
              <a
                href="#"
                className="text-white text-sm hover:text-[#ff9900] leading-10"
              >
                About
              </a>
            </li>
            <li>
              <a
                href="#"
                className="text-white text-sm hover:text-[#ff9900] leading-10"
              >
                Services
              </a>
            </li>
            <li>
              <a
                href="#"
                className="text-white text-sm hover:text-[#ff9900] leading-10"
              >
                Pricing
              </a>
            </li>
            <li>
              <a
                href="#"
                className="text-white text-sm hover:text-[#ff9900] leading-10"
              >
                Contact
              </a>
            </li>
            <li>
              <a
                href=""
                className="hover:bg-slate-900 flex items-center relative border border-[#ff9900] text-white px-3 rounded py-1"
              >
                <FaShoppingCart className="text-[#ff9900] mr-2" /> Carts
                <span className="bg-red-500 text-white top-[-10px] right-[-10px] flex items-center justify-center text-sm font-bold absolute rounded-full h-[20px] w-[20px]">
                  0
                </span>
              </a>
            </li>
          </ul>
        </div>
      </div>
    </nav>
  );
};

export default Header;
