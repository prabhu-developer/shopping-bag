import CategoriesMenu from '@/components/CategoriesMenu/CategoriesMenu.lazy'
import Header from '@/components/Header/Header.lazy'
import ProductsList from '@/components/ProductsList/ProductsList.lazy'
import SearchBar from '@/components/SearchBar/SearchBar.lazy'

export default function Home() {
  return (
      <main>
      <Header/>
      <SearchBar />
      <CategoriesMenu />
      <ProductsList/>
    </main>
  )
}
