import axios from "axios";

const https = axios.create({
  baseURL: "https://mock.redq.io/api/",
});

https.interceptors.response.use(
  (response) => {
    return response;
  },
  (error) => {
    return Promise.reject(error);
  }
);

export default https