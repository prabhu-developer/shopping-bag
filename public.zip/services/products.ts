import https from "./http";

const STORE_API = process.env.REACT_APP_STORE_API || "clothing";
const DEFAULT_LIMIT = 8;

const getCategories = async () => {
  const { data } = await https.get(
    `categories?search=type.slug:${STORE_API}&limit=10`
  );
  return data;
};

const getProductsByCategory = async (
  page: number = 1,
  name: string,
  searchString: string = ""
) => {

  const categoryQuery = name ? `categories.slug:${name};` : "";

  let url = `products?search=type.slug:${STORE_API};${categoryQuery}status:publish&limit=${DEFAULT_LIMIT}&page=${page}`;

  if (searchString !== null) {
    url = `products?searchJoin=and&with=type;author&search=type.slug:${STORE_API};name:${searchString}&limit=${DEFAULT_LIMIT}&page=${page}`;
  }

  const { data } = await https.get(url);
  return data;
};

export { getCategories, getProductsByCategory };
